# Toxic Bot Discord

Bot troll tag với lệnh `/tags` (5 tin nhắn ngẫu nhiên, cooldown 0.5s, chỉ 2 người dùng được).

## Cài đặt
1. Cập nhật USER ID trong `index.js`.
2. Cập nhật BOT_ID trong `deploy-commands.js`.
3. `npm install`
4. `npm run deploy` (đăng ký lệnh).
5. `npm start` (chạy bot).

## Deploy
- Render.com: Upload repo GitHub.
- Thêm biến: TOKEN =MTI5ODYxNDA2OTI0NjQzMTI0Mw.G7oW7D.nIJLozwfSwZPdisRbSGE18a5qZl9LbmhBglO_g.

Cảnh báo: Nội dung nặng, chỉ dùng troll vui vẻ!